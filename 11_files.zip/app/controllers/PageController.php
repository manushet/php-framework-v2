<?php


namespace app\controllers;


class PageController
{

    public function viewAction()
    {
        echo __METHOD__;
    }

}