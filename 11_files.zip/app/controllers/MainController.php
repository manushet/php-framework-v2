<?php

namespace app\controllers;


use wfm\Controller;

class MainController extends Controller
{

//    public false|string $layout = 'test2';

    public function indexAction()
    {
//        $this->layout = 'default';
    }

}