<?php

return [
    'admin_email' => 'admin@new-ishop.loc',
    'site_name' => 'E-Shop',
    'pagination' => 2,
];
